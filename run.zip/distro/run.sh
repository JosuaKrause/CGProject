#!/bin/sh

java -Xmx2g -Djava.library.path=native/ -jar cg-project.jar

